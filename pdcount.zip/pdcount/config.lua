Config = {}

Config.PoliceJobs = {
    'police',
    'sheriff',
    'sahp',
}